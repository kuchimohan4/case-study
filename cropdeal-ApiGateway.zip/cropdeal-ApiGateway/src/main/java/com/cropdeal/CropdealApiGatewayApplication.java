package com.cropdeal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CropdealApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CropdealApiGatewayApplication.class, args);
	}

}
