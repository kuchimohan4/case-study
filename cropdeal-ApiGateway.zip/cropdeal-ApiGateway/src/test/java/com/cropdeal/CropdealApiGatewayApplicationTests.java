package com.cropdeal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropdealApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
